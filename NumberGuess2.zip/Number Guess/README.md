phonegap-lifecycle-test
=======================
 A simple PhoneGap Build application that counts the occurances of application lifecycle events 
